This is where sleekdb is stored. Don't delete this folder.
You can delete any folder in this folder to clear the DB