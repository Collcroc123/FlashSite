<?php
class myecho {
    public function tehecho($data = array()) {
        return '<<TESTCONN>>';
    }
}